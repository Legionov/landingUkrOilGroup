jQuery(document).ready(function() {jQuery("#tel1, #tel2").mask("+380 (99) 999-99-99");});
